<?php

namespace App\Http\Controllers;

use App\Ticket;
use App\TicketReply;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth;
use Mail;
use App\Mail\TicketCreated;
use App\Mail\TicketUpdate;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $tickets = Ticket::all('subject', 'escalated', 'id', 'created_at', 'status', 'admin_id')->where('admin_id', '=', 0)->where('status', '=', 1)->sortBy('id');

      if(sizeof($tickets) == 0) return view('ticketlist');
      return view('ticketlist')->with(['tickets' => $tickets, 'power' => auth()->user()->power]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createticket');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $name = auth()->user()->username;
        $id = auth()->user()->id;

        request()->validate([
          'subject' => 'required|min:5',
          'issue' => 'required|min:30|max:500',
        ]);

        $ticket = new Ticket();

        $ticket->account_id = $id;
        $ticket->subject = $request['subject'];
        $ticket->issue = $request['issue'];
        $ticket->username = $name;

        $ticket->save();

        Mail::to(auth()->user()->email)->queue(new TicketCreated());

        return redirect('/home');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function show(Ticket $ticket)
    {
        $replies = TicketReply::all('admin_name', 'user_name', 'reply', 'created_at')->where('ticket_id', '=', $ticket->ticket_id)->sortBy('created_at');

        if(auth()->user()->power > 1)
        {
          return view('adminticket')->with(['ticket' => $ticket, 'replies' => $replies]);
        }
    }

    public function pshow(Ticket $ticket)
    {
      $replies = TicketReply::all('admin_name', 'user_name', 'reply', 'created_at')->where('ticket_id', '=', $ticket->ticket_id)->sortBy('created_at');
      return view('pticket')->with(['ticket' => $ticket, 'replies' => $replies]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function edit(Ticket $ticket)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ticket $ticket)
    {
        if(isset($request['reply']))
        {
          $ticket->status = 2;
          $message = $request['reply-text'];
          $admin = auth()->user()->username;
        }
        else if(isset($request['escalate']))
        {
          $ticket->status = 1;
          $escalated = $ticket->escalated;
          $ticket->escalated = $escalated + 1;
          $ticket->admin_id = 0;
          if($request['reply-text'] == "" || !isset($request['reply-text']))
          {
            $admin = "Admin";
            $message = "The current Administrator has marked this ticket for escalation. A higher Admin will handle this ticket ASAP.";
          }
          else {
            $admin = auth()->user()->username;
            $message = $request['reply-text'];
          }

        }
        else {
          if(!isset($request['reply-text']) || $request['reply-text'] == "")
          {
            $admin = "Admin";
            $ticket->status = 0;
            $message = "The current Administrator has marked this ticket as solved due to the issue being solved or inactivity.";
          }
          else {
            $admin = auth()->user()->username;
            $ticket->status = 0;
            $message = $request['reply-text'];
          }

        }

        $ticket->save();

        Mail::to(auth()->user()->email)->queue(new TicketUpdate());

        $reply = new TicketReply();

        $reply->ticket_id = $ticket->id;
        $reply->admin_name = $admin;
        $reply->reply = $message;
        $reply->save();

        return redirect('/admin/mytickets');
    }

    public function pupdate(Request $request, Ticket $ticket)
    {
        if(isset($request['reply']))
        {
          $ticket->status = 1;
        }

        $ticket->save();

        $reply = new TicketReply();

        request()->validate([
          'reply-text' => 'required|min:10',
        ]);

        $reply->ticket_id = $ticket->id;
        $reply->user_name = auth()->user()->username;
        $reply->reply = $request['reply-text'];
        $reply->save();

        return redirect('/mytickets');
    }

    public function handle(Request $request, Ticket $ticket)
    {
        $id = auth()->user()->id;

        $ticket->admin_id = $id;
        $ticket->save();

        return redirect('/admin/mytickets')->with('message', "The ticket has been added to your list.");
    }

    public function alist()
    {
      $tickets = Ticket::all('subject', 'escalated', 'id', 'updated_at', 'created_at', 'admin_id', 'status')
      ->where('admin_id', '=', auth()->user()->id)
      ->where('status', '!=', 0)->sortBy('updated_at');

      if(sizeof($tickets) == 0) return view('tickets');
      return view('tickets')->with('tickets', $tickets);
    }


    public function plist()
    {
      $id = auth()->user()->id;

      $tickets = Ticket::orderBy('updated_at', 'DESC')->where('account_id', '=', $id)->take(25)->get();


      if(sizeof($tickets) == 0) return view('ptickets');
      return view('ptickets')->with('tickets', $tickets);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ticket $ticket)
    {
        //
    }
}
