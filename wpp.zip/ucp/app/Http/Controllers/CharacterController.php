<?php

namespace App\Http\Controllers;

use App\Character;
use App\User;
use Mail;
use App\Mail\CharacterNeedConfirm;
use App\Http\Controllers\Auth;
use Illuminate\Http\Request;

class CharacterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function list()
    {
      //add skin to the select query
      $characters = Character::all('CharName','id', 'account_name')->where('confirmed', '=', 0)->sortBy('id');
      if(sizeof($characters) == 0) return view('list');
      else return view('list')->with('characters', $characters);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        /*$user = auth()->user();
        return dd($user->isAdmin($user));*/

        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
          'firstname' => 'required|min:3|alpha',
          'lastname' => 'required|min:3|alpha',
          'year' => 'required|min:1930|max:2000|numeric',
          'origin' => 'required|min:0|max:9|numeric',
          'gender' => 'required|numeric',
        ]);

        $name = $request['firstname'] . "_" . $request['lastname'];

        try{
          Character::create([
            'account_id' => auth()->user()->id,
            'account_name' => auth()->user()->username,
            'CharName' => $name,
            'year' => $request['year'],
            'origin' => $request['origin'],
            'gender' => $request['gender'],
          ]);
        }
        catch(\Illuminate\Database\QueryException $e)
        {
          $errorCode = $e->errorInfo[1];
          if($errorCode == '1062'){
                dd('Duplicate Entry');
            }
        }

        $email = auth()->user()->email;
        Mail::to($email)->queue(new CharacterNeedConfirm());

        redirect('/home')->with('notification', 'Your character application was sent. More information will be sent via Email.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Character  $character
     * @return \Illuminate\Http\Response
     */
    public function show(Character $character)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Character  $character
     * @return \Illuminate\Http\Response
     */
    public function edit(Character $character)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Character  $character
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Character $character)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Character  $character
     * @return \Illuminate\Http\Response
     */
    public function destroy(Character $character)
    {
        //
    }

    public function review(Request $request, $characterid)
    {
        $holder = new Character;
        if(isset($request['accepted']))
        {
          $holder->accept($characterid);
        }
        else if(isset($request['dennied']))
        {
          $holder->deny($characterid);
        }
        else {
          abort(401, "Access to this page is restricted.");
        }

        return redirect('/admin/character/list')->with('notification', "Character application succesfully processed.");
    }

    /**
    *Same as update but used only by admins
    *Is used for reviewing accounts
    *for the time being
    */


}
