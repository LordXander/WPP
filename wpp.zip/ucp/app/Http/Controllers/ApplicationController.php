<?php

namespace App\Http\Controllers;

use App\Application;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth;
use Illuminate\Support\Arr;
use Mail;
use Illuminate\Support\Facades\DB;
use App\Mail\ApplicationAccepted;
use App\Mail\ApplicationDenied;
use App\Mail\ApplicationRecived;

class ApplicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $apps = Application::all('username', 'id', 'created_at')->where('accepted', '=', 0)->sortBy('created_at');
        if(sizeof($apps) == 0) return view('applist');
        return view('applist')->with('apps', $apps);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $array = [0, 1, 2, 3];
      $random = Arr::random($array);

      return view('application')->with('situation', $random);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
          'answer1' => 'required|min:10',
          'answer2' => 'required|min:10',
          'answer3' => 'required|min:10',
          'answer4' => 'required|min:10',
          'answer5' => 'required|min:10',
          'question5' => 'required|min:0|max:3|numeric',
        ]);

        $app = new Application();
        $email = auth()->user()->email;

        $app->account_id=auth()->user()->id;
        $app->username=auth()->user()->username;
        $app->email = $email;
        $app->answer1 = $request['answer1'];
        $app->answer2 = $request['answer2'];
        $app->answer3 = $request['answer3'];
        $app->answer4 = $request['answer4'];
        $app->answer5 = $request['answer5'];
        $app->question5 = $request['question5'];

        Mail::to($email)->queue(new ApplicationRecived());

        $app->save();

        return redirect('/home')->with('notification', "Your application has been created. You will be notified via mail for all the updates regarding your application.");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Application  $application
     * @return \Illuminate\Http\Response
     */
    public function show(Application $application)
    {
        return view('appreview')->with('application', $application);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Application  $application
     * @return \Illuminate\Http\Response
     */
    public function edit(Application $application)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Application  $application
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Application $application)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Application  $application
     * @return \Illuminate\Http\Response
     */
    public function destroy(Application $application)
    {
        //
    }

    public function review(Application $application, Request $request)
    {
      $admin = auth()->user()->username;
      $email = $application->email;
      $reason = "N/A";

      if(isset($request['accept']))
      {
        $accepted = 1;
        Mail::to($email)->queue(new ApplicationAccepted());


        DB::table('users')->where('id', $application->account_id)->update(['confirmed' => 1]);

      }
      else {
        $accepted = 2;
        $reason = $request['reason'];
        Mail::to($email)->queue(new ApplicationDenied($reason));
      }

      DB::table('applications_archive')->insert(
        [
          'account_id' => $application->account_id,
          'username' => $application->username,
          'answer1' => $application->answer1,
          'answer2' => $application->answer2,
          'answer3' => $application->answer3,
          'answer4' => $application->answer4,
          'answer5' => $application->answer5,
          'question5' => $application->question5,
          'accepted' => $accepted,
          'adminName' => $admin,
          'reason' => $reason,
      ]);

      $application->delete();

      return redirect('/admin/application/list')->with('notification', 'The application was succesfully reviewed');
    }
}
