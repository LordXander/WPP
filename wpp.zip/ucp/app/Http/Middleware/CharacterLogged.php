<?php

namespace App\Http\Middleware;

use Closure;
use Cookie;
use Session;

class CharacterLogged
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        Session::forget('character');
        if(Session::exists('character'))
        {
          return $next($request);
        }
        else {
          return route('login');
        }

    }
}
