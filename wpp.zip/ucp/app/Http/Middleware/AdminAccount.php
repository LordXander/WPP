<?php

namespace App\Http\Middleware;

use Closure;
use App\Http\Controllers\Auth;

class AdminAccount
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $power = auth()->user()->power;

        if($request->is('review/*'))
        {
            if($power < 1) abort(403, 'Special privileges required. If should be granted, contact the Management/Development Team');
            return $next($request);
        }
        else if($request->is('admin/*'))
        {
          if($power < 2) abort(403, 'Special privileges required. If should be granted, contact the Management/Development Team');
          //access granted only to admins
          return $next($request);
        }
        else if($request->is('application/list'))
        {
          if($power < 1) abort(403, 'Special privileges required. If should be granted, contact the Management/Development Team');
          //access granted only to admins & testers
          return $next($request);
        }
        else if($request->is('application/answer/*'))
        {
          if($power < 1) abort(403, 'Special privileges required. If should be granted, contact the Management/Development Team');
          //access granted only to admins & testers
          return $next($request);
        }
        else {
          abort(503, "The page - | " . $path . " | is not available. Please contact the Development team with the page you tried to access.");
        }
    }
}
