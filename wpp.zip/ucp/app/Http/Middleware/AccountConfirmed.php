<?php

namespace App\Http\Middleware;

use Closure;
use App\Http\Controllers\Auth;

class AccountConfirmed
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $data = auth()->user()->confirmed;
        if($data == 1)
        {
          $path = $request->path();
          if($path == 'application')
          {
            abort(401, 'Access Denied - Error:@r3512t3r');
          }

          return $next($request);
        }
        if($data == 2)
        {
          return route('banned');
        }
        else {
         return redirect('/home');
        }

    }
}
