<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use Mail;
use App\Mail\CharacterAccepted;
use App\Mail\CharacterDenied;

class Character extends Model
{
  protected $fillable = [
      'account_id', 'account_name', 'CharName', 'year', 'origin', 'gender',
  ];

  public $timestamps = false;

  public function accept($characterid)
  {
    $character = Character::all()->where('id', '=', $characterid)->first();

    Character::where('id', '=', $characterid)->update(['confirmed' => 1]);

    Character::where('id', '=', $characterid)->delete();

    $user = User::select('email')->where('id', '=', $character['account_id'])->first();

    Mail::to($user['email'])->queue(new CharacterAccepted());

    return $user['email'];
  }

  public function deny($characterid)
  {
    $character = Character::all()->where('id', '=', $characterid)->first();

    Character::where('id', '=', $characterid)->delete();

    $user = User::select('email')->where('id', '=', $character['account_id'])->first();

    Mail::to($user['email'])->queue(new CharacterDenied());

    return $user;
  }
}
