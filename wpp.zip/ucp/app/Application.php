<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Application extends Model
{
  protected $fillable = [
      'answer1', 'answer2', 'answer3', 'answer4', 'answer5', 'question5',
  ];
}
