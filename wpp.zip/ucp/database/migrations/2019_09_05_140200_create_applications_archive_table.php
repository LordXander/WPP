<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApplicationsArchiveTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applications_archive', function (Blueprint $table) {
          $table->bigIncrements('id');
          $table->integer('account_id');
          $table->string('username', 255);
          $table->text('answer1');
          $table->text('answer2');
          $table->text('answer3');
          $table->text('answer4');
          $table->text('answer5');
          $table->integer('question5');
          $table->integer('accepted')->default(0);
          $table->string('adminName', 35);
          $table->text('reason');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applications_archive');
    }
}
