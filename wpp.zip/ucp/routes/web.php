<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes(['verify' => true]);



Route::get('/home', 'HomeController@index');

Route::get('/create', 'CharacterController@create')->middleware(['auth', 'verified', 'confirmed']);
Route::get('/admin/character/list', 'CharacterController@list')->middleware(['auth', 'verified', 'confirmed', 'admin']);
Route::post('/save', 'CharacterController@store')->middleware(['auth', 'verified', 'confirmed']);
Route::patch('/admin/character/review/{character}', 'CharacterController@review')->middleware(['auth', 'admin']);
Route::get('/application', 'ApplicationController@create')->middleware(['auth', 'verified']);
Route::post('/saveapp', 'ApplicationController@store')->middleware(['auth', 'verified']);
Route::get('/playerlist', 'CharacterController@playerlist')->middleware(['auth', 'admin']);
Route::get('/admin/application/list', 'ApplicationController@index')->middleware(['auth', 'admin']);
Route::patch('/admin/application/review/{application}', 'ApplicationController@show')->middleware(['auth', 'admin']);
Route::patch('/admin/application/answer/{application}', 'ApplicationController@review')->middleware(['auth', 'admin']);
Route::get('/admin/tickets', 'TicketController@index')->middleware(['auth', 'admin']);
Route::get('/createticket', 'TicketController@create')->middleware(['auth', 'verified']);
Route::post('/saveticket', 'TicketController@store')->middleware(['auth', 'verified']);
Route::get('/mytickets', 'TicketController@plist')->middleware(['auth', 'verified']);
Route::patch('/mytickets/view/{ticket}', 'TicketController@pshow')->middleware(['auth', 'verified']);
Route::get('/admin/ticketlist', 'TicketController@index')->middleware(['auth', 'verified', 'admin']);
Route::patch('/admin/ticket/view/{ticket}', 'TicketController@show')->middleware(['auth', 'verified', 'admin']);
Route::patch('/admin/ticket/handle/{ticket}', 'TicketController@handle')->middleware(['auth', 'verified', 'admin']);
Route::patch('/admin/ticket/reply/{ticket}', 'TicketController@update')->middleware(['auth', 'verified', 'admin']);
Route::get('/admin/mytickets', 'TicketController@alist')->middleware(['auth', 'verified', 'admin']);
