<?php $__env->startComponent('mail::message'); ?>
<p>Hi,</p>
<p>We are happy to let you know that your character was accepted and you can now join the server.</p>
<p>The adress is: serveradress:7777</p>
<br>

Thanks,<br>
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/ucp/resources/views/emails/character-accepted.blade.php ENDPATH**/ ?>