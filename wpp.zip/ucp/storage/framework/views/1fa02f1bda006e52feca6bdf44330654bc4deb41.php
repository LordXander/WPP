

<?php $__env->startSection('content'); ?>

<?php if(isset($tickets)): ?>
  <h1>Current Tickets</h1>
  <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($ticket->status != 0): ?>
      <div class="ticket">
        <p class="mastername"><?php echo e($ticket->subject); ?></p>
        <p class="createdat"><?php echo e($ticket->created_at); ?></p>
        <?php if($ticket->status == 1): ?>
        <div class="no-reply">
          <p>No reply</p>
        </div>
        <?php else: ?>
        <div class="replied">
            <p>Waiting for reply</p>
        </div>
        <?php endif; ?>
        <div class="ticket-options">
          <form class="view-ticket" action="/mytickets/view/<?php echo e($ticket->id); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" name="view">View Ticket</button>
          </form>
        </div>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <h2>Tickets Archive</h2>
  <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($ticket->status == 0): ?>
      <div class="ticket">
        <p class="mastername"><?php echo e($ticket->subject); ?></p>
        <p class="createdat"><?php echo e($ticket->created_at); ?></p>
        <div class="ticket-options">
          <form class="view-ticket" action="/mytickets/view/<?php echo e($ticket->id); ?>" method="POST">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" name="view">View Ticket</button>
          </form>
        </div>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<h1>No tickets were found</h1>
<?php endif; ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/ptickets.blade.php ENDPATH**/ ?>