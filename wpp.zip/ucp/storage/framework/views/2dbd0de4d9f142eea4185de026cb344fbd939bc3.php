<?php $__env->startComponent('mail::message'); ?>
<p>Hi,</p>

<p>This is an email to inform your your character was created and awaits a small verification process.</p>

<p>This process should't take more than a couple of minutes.</p>
(during 8:00AM - 12:00PM)

<p>If you haven't heard back from us in more than 2 hours and in the ucp the character still shows as Pending, please get in touch wih us via a ticket.</p>

Thanks,<br>
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/ucp/resources/views/emails/character-created.blade.php ENDPATH**/ ?>