<?php $__env->startComponent('mail::message'); ?>
<p>After reviewing your application, we had to deny it for the following reason(s).</p>
<br>
<p>Reason: <?php echo e($reason); ?></p>
<p>We are sorry for this and wish you the best in the future.</p>

Thanks,<br>
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/ucp/resources/views/emails/application-denied.blade.php ENDPATH**/ ?>