

<?php $__env->startSection('content'); ?>

<?php if(isset($apps)): ?>
<?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p class="mastername"><?php echo e($app['username']); ?></p>
<p class="createdat"><?php echo e($app['created_at']); ?></p>
<form class="appselect" action="/admin/application/review/<?php echo e($app->id); ?>" method="POST">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <button type="submit" name="review">View App</button>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h1></h1>
<?php endif; ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/applist.blade.php ENDPATH**/ ?>