

<?php $__env->startSection('content'); ?>

<form action="/save" method="POST">
  <?php echo csrf_field(); ?>
  <input type="text" name="firstname" placeholder="First Name" value="<?php echo e(old('firstname')); ?>">
  <input type="text" name="lastname" placeholder="Last Name" value="<?php echo e(old('lastname')); ?>">
  <input type="number" name="year" placeholder="Age" value="<?php echo e(old('age')); ?>">
  <select name="gender">
    <option value="0">Male</option>
    <option value="1">Female</option>
  </select>
  <select name="origin">
    <option value="0">San Andreas</option>
    <option value="1">Europe</option>
    <option value="2">US</option>
    <option value="3">Russia</option>
    <option value="4">China</option>
    <option value="5">Japan</option>
    <option value="6">Australia</option>
    <option value="7">Greenland</option>
    <option value="8">Canada</option>
  </select>
  <button type="submit" name="button">Create</button>
</form>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/create.blade.php ENDPATH**/ ?>