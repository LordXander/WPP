

<?php $__env->startSection('content'); ?>

<form action="/saveticket" method="POST">
  <?php echo csrf_field(); ?>
  <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="Ticket title">
  <textarea name="issue" rows="8" cols="80" value="<?php echo e(old('issue')); ?>" placeholder="Describe the issue as clear as possible"></textarea>
  <button type="submit" name="button">Create</button>
</form>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/createticket.blade.php ENDPATH**/ ?>