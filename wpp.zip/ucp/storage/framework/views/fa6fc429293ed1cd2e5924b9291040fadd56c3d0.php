<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Register</title>
  </head>
  <body>
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
  </body>
</html>
<?php /**PATH /home/vagrant/code/ucp/resources/views/layouts/ucp.blade.php ENDPATH**/ ?>