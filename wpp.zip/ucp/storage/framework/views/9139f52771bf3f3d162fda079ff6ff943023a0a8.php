

<?php $__env->startSection('content'); ?>

<?php if(isset($tickets)): ?>
  <?php if($power > 8): ?>
  <div class="Management">
      <h2>Management Tickets</h2>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ticket->escalated == 4): ?>
          <div class="ticket">
            <p class="mastername"><?php echo e($ticket->subject); ?></p>
            <p class="createdat"><?php echo e($ticket->created_at); ?></p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="handle-ticket" action="/admin/ticket/handle/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
  <?php if($power >= 8): ?>
  <div class="HeadAdmin">
      <h2>Head Admin Tickets</h2>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ticket->escalated == 3): ?>
          <div class="ticket">
            <p class="mastername"><?php echo e($ticket->subject); ?></p>
            <p class="createdat"><?php echo e($ticket->created_at); ?></p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>

  <?php if($power >= 7): ?>
  <div class="LeadAdmin">
      <h2>Lead Admin Tickets</h2>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ticket->escalated == 2): ?>
          <div class="ticket">
            <p class="mastername"><?php echo e($ticket->subject); ?></p>
            <p class="createdat"><?php echo e($ticket->created_at); ?></p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
  <?php if($power >= 5): ?>
  <div class="SeniorAdmin">
      <h2>Senior Admin Tickets</h2>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ticket->escalated == 1): ?>
          <div class="ticket">
            <p class="mastername"><?php echo e($ticket->subject); ?></p>
            <p class="createdat"><?php echo e($ticket->created_at); ?></p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
  <?php if($power >= 2): ?>
  <div class="Admin">
      <h2>Admin Tickets</h2>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($ticket->escalated == 0): ?>
          <div class="ticket">
            <p class="mastername"><?php echo e($ticket->subject); ?></p>
            <p class="createdat"><?php echo e($ticket->created_at); ?></p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/<?php echo e($ticket->id); ?>" method="POST">
                <?php echo method_field('PATCH'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>

<?php else: ?>
<h1>No tickets were found</h1>
<?php endif; ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/ticketlist.blade.php ENDPATH**/ ?>