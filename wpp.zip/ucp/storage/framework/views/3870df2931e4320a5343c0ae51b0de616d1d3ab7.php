

<?php $__env->startSection('content'); ?>
<?php if(isset($characters)): ?>

  <?php $__currentLoopData = $characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p>Username: <?php echo e($character->CharName); ?></p>
      <?php if($character->gender == 0): ?>
        </<?php
          $gender = "Male";
        ?>
      <?php else: ?>
        </<?php
          $gender = "Female";
        ?>
      <?php endif; ?>
      <p>Gender: <?php echo e($gender); ?></p>
      <p>Master Account: <?php echo e($character->account_name); ?></p>
      <div class="char-answer">
        <form class="accept-char" action="/admin/character/review/<?php echo e($character->id); ?>" method="post">
          <?php echo method_field('PATCH'); ?>
          <?php echo csrf_field(); ?>
          <button type="submit" name="accepted">Accept</button>
        </form>
        <form class="deny-char" action="/admin/character/review/<?php echo e($character->id); ?>" method="post">
          <?php echo method_field('PATCH'); ?>
          <?php echo csrf_field(); ?>
          <button type="submit" name="dennied">Deny</button>
        </form>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
  <?php echo e("No characters found"); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/list.blade.php ENDPATH**/ ?>