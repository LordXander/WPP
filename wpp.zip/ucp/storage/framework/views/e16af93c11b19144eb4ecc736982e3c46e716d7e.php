

<?php $__env->startSection('content'); ?>

<div class="ticketTitle">
  <h2><?php echo e($ticket->subject); ?> | #<?php echo e($ticket->id); ?></h2>
  <p>Ticket created at: <?php echo e($ticket->created_at); ?></p>
  <p>Last update: <?php echo e($ticket->updated_at); ?></p>
</div>

<div class="ticketIssue">
  <p><?php echo e($ticket->issue); ?></p>
</div>

<?php if(isset($replies)): ?>
<?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="reply">
  <?php if($reply['admin_name'] != "NULL"): ?>
    <div class="admin-author">
      <h4><?php echo e($reply['admin_name']); ?></h4>
      <p><?php echo e($reply['created_at']); ?></p>
    </div>
    <div class="reply-text-admin">
      <?php echo e($reply['reply']); ?>

    </div>
  <?php else: ?>
    <div class="user-author">
      <h4><?php echo e($reply['user_name']); ?></h4>
      <p><?php echo e($reply['created_at']); ?></p>
    </div>
    <div class="reply-text-user">
      <?php echo e($reply['reply']); ?>

    </div>
  <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($ticket->status != 0): ?>
<form class="" action="/ticket/reply/<?php echo e($ticket->id); ?>" method="post">
  <?php echo method_field('PATCH'); ?>
  <?php echo csrf_field(); ?>
  <textarea name="reply-text" rows="8" cols="80" placeholder="Message" required value = <?php echo e(old('reply-text')); ?>></textarea>
  <button type="submit" name="reply">Reply</button>
</form>
<?php endif; ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ucp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/ucp/resources/views/pticket.blade.php ENDPATH**/ ?>