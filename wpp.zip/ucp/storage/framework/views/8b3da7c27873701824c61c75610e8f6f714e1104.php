<?php $__env->startComponent('mail::message'); ?>
<p>After reviewing your character application, we had to deny it for the following reason(s):</p>
<p>The reason for this decission is regarding our policies about in-game names. Please check our rules on the forum.</p>
<br>
If you still don't understand the reason, please contact our staff via a ticket.

<p>We are sorry for this and wish you the best in the future.</p>
<br>
Thanks,<br>
<?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/ucp/resources/views/emails/character-denied.blade.php ENDPATH**/ ?>