@extends('layouts.ucp')

@section('content')

@if(isset($tickets))
  @foreach ($tickets as $ticket)
      <div class="ticket">
        <p class="mastername">{{$ticket->subject}}</p>
        <p class="createdat">{{$ticket->created_at}}</p>
        <p class="updateddat">{{$ticket->updated_at}}</p>
        @if($ticket->status == 1)
        <div class="replied">
          <p>Waiting for reply</p>
        </div>
      @elseif($ticket->status == 2)
        <div class="no-reply">
            <p>No reply</p>
        </div>
      @endif
        <div class="ticket-options">
          <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
            @method('PATCH')
            @csrf
            <button type="submit" name="view">View Ticket</button>
          </form>
        </div>
      </div>
  @endforeach

@else
<h1>No tickets were found</h1>
@endif

@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
