@extends('layouts.ucp')

@section('content')

@if(isset($apps))
@foreach ($apps as $app)
<p class="mastername">{{$app['username']}}</p>
<p class="createdat">{{$app['created_at']}}</p>
<form class="appselect" action="/admin/application/review/{{$app->id}}" method="POST">
  @method('PATCH')
  @csrf
  <button type="submit" name="review">View App</button>
</form>
@endforeach
@else
<h1></h1>
@endif

@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
