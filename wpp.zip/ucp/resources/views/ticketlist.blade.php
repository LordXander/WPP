@extends('layouts.ucp')

@section('content')

@if(isset($tickets))
  @if($power > 8)
  <div class="Management">
      <h2>Management Tickets</h2>
      @foreach ($tickets as $ticket)
        @if($ticket->escalated == 4)
          <div class="ticket">
            <p class="mastername">{{$ticket->subject}}</p>
            <p class="createdat">{{$ticket->created_at}}</p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="handle-ticket" action="/admin/ticket/handle/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        @endif
      @endforeach
  </div>
  @endif
  @if($power >= 8)
  <div class="HeadAdmin">
      <h2>Head Admin Tickets</h2>
      @foreach ($tickets as $ticket)
        @if($ticket->escalated == 3)
          <div class="ticket">
            <p class="mastername">{{$ticket->subject}}</p>
            <p class="createdat">{{$ticket->created_at}}</p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        @endif
      @endforeach
  </div>
  @endif

  @if($power >= 7)
  <div class="LeadAdmin">
      <h2>Lead Admin Tickets</h2>
      @foreach ($tickets as $ticket)
        @if($ticket->escalated == 2)
          <div class="ticket">
            <p class="mastername">{{$ticket->subject}}</p>
            <p class="createdat">{{$ticket->created_at}}</p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        @endif
      @endforeach
  </div>
  @endif
  @if($power >= 5)
  <div class="SeniorAdmin">
      <h2>Senior Admin Tickets</h2>
      @foreach ($tickets as $ticket)
        @if($ticket->escalated == 1)
          <div class="ticket">
            <p class="mastername">{{$ticket->subject}}</p>
            <p class="createdat">{{$ticket->created_at}}</p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        @endif
      @endforeach
  </div>
  @endif
  @if($power >= 2)
  <div class="Admin">
      <h2>Admin Tickets</h2>
      @foreach ($tickets as $ticket)
        @if($ticket->escalated == 0)
          <div class="ticket">
            <p class="mastername">{{$ticket->subject}}</p>
            <p class="createdat">{{$ticket->created_at}}</p>
            <div class="ticket-options">
              <form class="view-ticket" action="/admin/ticket/view/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="view">View Ticket</button>
              </form>
              <form class="view-ticket" action="/admin/ticket/handle/{{$ticket->id}}" method="POST">
                @method('PATCH')
                @csrf
                <button type="submit" name="handle">Handle Ticket</button>
              </form>
            </div>
          </div>
        @endif
      @endforeach
  </div>
  @endif

@else
<h1>No tickets were found</h1>
@endif

@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
