<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Register</title>
  </head>
  <body>
    <main class="py-4">
        @yield('content')
    </main>
  </body>
</html>
