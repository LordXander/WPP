@extends('layouts.ucp')

@section('content')

<div class="ticketTitle">
  <h2>{{$ticket->subject}} | #{{$ticket->id}}</h2>
  <p>Ticket created at: {{$ticket->created_at}}</p>
  <p>Last update: {{$ticket->updated_at}}</p>
</div>

<div class="ticketIssue">
  <p>{{$ticket->issue}}</p>
</div>

@if(isset($replies))
@foreach ($replies as $reply)
<div class="reply">
  @if($reply['admin_name'] != "NULL")
    <div class="admin-author">
      <h4>{{$reply['admin_name']}}</h4>
      <p>{{$reply['created_at']}}</p>
    </div>
    <div class="reply-text-admin">
      {{$reply['reply']}}
    </div>
  @else
    <div class="user-author">
      <h4>{{$reply['user_name']}}</h4>
      <p>{{$reply['created_at']}}</p>
    </div>
    <div class="reply-text-user">
      {{$reply['reply']}}
    </div>
  @endif
</div>
@endforeach
@endif

@if($ticket->admin_id != 0 || $ticket->status != 0)
<form class="" action="/admin/ticket/reply/{{$ticket->id}}" method="post">
  @method('PATCH')
  @csrf
  <textarea name="reply-text" rows="8" cols="80" placeholder="Message" value = {{old('reply-text')}}></textarea>
  <button type="submit" name="reply">Reply</button>
  <button type="submit" name="solved">Mark issue as solved</button>
  <button type="submit" name="escalate">Escalate this issue</button>
</form>
@endif
@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
