@extends('layouts.ucp')

@section('content')

@if(isset($tickets))
  <h1>Current Tickets</h1>
  @foreach ($tickets as $ticket)
    @if($ticket->status != 0)
      <div class="ticket">
        <p class="mastername">{{$ticket->subject}}</p>
        <p class="createdat">{{$ticket->created_at}}</p>
        @if($ticket->status == 1)
        <div class="no-reply">
          <p>No reply</p>
        </div>
        @else
        <div class="replied">
            <p>Waiting for reply</p>
        </div>
        @endif
        <div class="ticket-options">
          <form class="view-ticket" action="/mytickets/view/{{$ticket->id}}" method="POST">
            @method('PATCH')
            @csrf
            <button type="submit" name="view">View Ticket</button>
          </form>
        </div>
      </div>
    @endif
  @endforeach

  <h2>Tickets Archive</h2>
  @foreach ($tickets as $ticket)
    @if($ticket->status == 0)
      <div class="ticket">
        <p class="mastername">{{$ticket->subject}}</p>
        <p class="createdat">{{$ticket->created_at}}</p>
        <div class="ticket-options">
          <form class="view-ticket" action="/mytickets/view/{{$ticket->id}}" method="POST">
            @method('PATCH')
            @csrf
            <button type="submit" name="view">View Ticket</button>
          </form>
        </div>
      </div>
    @endif
  @endforeach

@else
<h1>No tickets were found</h1>
@endif

@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
