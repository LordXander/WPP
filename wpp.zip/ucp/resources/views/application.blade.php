@extends('layouts.ucp')

@section('content')

  <?php
  $version = $situation;
  switch ($situation) {
    case 0:
    {
      $situation = 'What are you supposed to do when an offier asks for your ID while you know you have a "piece" on you?<br />(noun: piece = possesion of a firearm illegaly)';
      break;
    }
    case 1:
    {
      $situation = 'Someone breaks into your house and you grab your weapon from the nightshelf. What are you going to do next?';
      break;
    }
    case 2:
    {
      $situation = 'You walk down on some dark alley and someone starts calling you names. You know that individual as some old bully and you also have your weapon with you. What are you going to do?';
      break;
    }
    case 3:
    {
      $situation = 'You are in a store with your girlfriend/wife waiting in a queue at the checking table. Some individual decides to cut in front of you. What are you going to do?';
    }
    default:
        $situation = 'What are you supposed to do when an offier asks for your ID while you know you have a "piece" on you?<br />(noun: piece = possesion of a firearm illegaly)';
      break;
  }
   ?>

<form action="/saveapp" method="POST">
  @csrf
  <label for="answer1">What is the definition of MG (Meta-Gaming)?</label>
  <textarea name="answer1" rows="8" cols="80"></textarea>
  <label for="answer2">What is the definition of PG (Power-Gaming)?</label>
  <textarea name="answer2" rows="8" cols="80"></textarea>
  <label for="answer3">Explain the rules regarding robbing & the limitations.</label>
  <textarea name="answer3" rows="8" cols="80"></textarea>
  <label for="answer4">Write the story for your first character you will have.</label>
  <textarea name="answer4" rows="8" cols="80"></textarea>
  <label for="answer5">{!!$situation!!}</label>
  <textarea name="answer5" rows="8" cols="80"></textarea>
  <button type="submit" name="button">Create</button>
  <input type="number" name="question5" value="{{$version}}" hidden>
</form>
@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
