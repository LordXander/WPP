@component('mail::message')
  <p>Hi,</p>

  <p>This is a mail to inform you that your ticket recived an update.</p>

  <p>Please reply in the next <b>48h</b> otherwise your ticket will be marked as solved.</p>

  <br>
  Thanks,<br>
  {{ config('app.name') }} Team
@endcomponent
