@component('mail::message')
<p>Hi, </p>
<p>This is an email to confirm we recived your application. Please be patient and do not contact our staff in reagards to your application unless you were otherwise instructed by our team.</p>

<p>Failing to comply with this rule will result in your application to be <b>denied</b>.</p>
<br>
<p>We wish you the best.</p>

Thanks,<br>
{{ config('app.name') }} Team
@endcomponent
