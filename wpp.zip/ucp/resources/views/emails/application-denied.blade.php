@component('mail::message')
<p>Hi,</p>
<p>After reviewing your application, we had to deny it for the following reason(s).</p>
<p>Reason:<b>{{$reason}}</b> </p>
<p>We are sorry for this and wish you the best in the future.</p>
<br>
Thanks,<br>
{{ config('app.name') }} Team
@endcomponent
