@component('mail::message')
<p>Hi,</p>

<p>This is a mail to confirm that we recived your ticket and will try to handle it as soon as possible</p>

<br>
Thanks,<br>
{{ config('app.name') }} Team
@endcomponent
