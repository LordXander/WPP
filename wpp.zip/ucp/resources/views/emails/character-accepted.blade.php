@component('mail::message')
<p>Hi,</p>
<p>We are happy to let you know that your character was accepted and you can now join the server.</p>
<p>The adress is: serveradress:7777</p>
<br>

Thanks,<br>
{{ config('app.name') }} Team
@endcomponent
