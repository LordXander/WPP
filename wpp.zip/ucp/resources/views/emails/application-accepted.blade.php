@component('mail::message')
<p>Hi,</p>

<p>We are happy to let you know that your application was accepted and as a result, you can now create your characters.</p>

<p>Please visit the ucp, log-in and a new button should be displayed allowing you to create the characters.</p>

Thanks,<br>
{{ config('app.name') }} Team
@endcomponent
