@extends('layouts.ucp')

@section('content')

<form action="/save" method="POST">
  @csrf
  <input type="text" name="firstname" placeholder="First Name" value="{{ old('firstname') }}">
  <input type="text" name="lastname" placeholder="Last Name" value="{{ old('lastname') }}">
  <input type="number" name="year" placeholder="Age" value="{{ old('age') }}">
  <select name="gender">
    <option value="0">Male</option>
    <option value="1">Female</option>
  </select>
  <select name="origin">
    <option value="0">San Andreas</option>
    <option value="1">Europe</option>
    <option value="2">US</option>
    <option value="3">Russia</option>
    <option value="4">China</option>
    <option value="5">Japan</option>
    <option value="6">Australia</option>
    <option value="7">Greenland</option>
    <option value="8">Canada</option>
  </select>
  <button type="submit" name="button">Create</button>
</form>
@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
