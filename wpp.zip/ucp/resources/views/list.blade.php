@extends('layouts.app')

@section('content')
@if(isset($characters))

  @foreach ($characters as $character)
      <p>Username: {{$character->CharName}}</p>
      @if($character->gender == 0)
        </@php
          $gender = "Male";
        @endphp
      @else
        </@php
          $gender = "Female";
        @endphp
      @endif
      <p>Gender: {{$gender}}</p>
      <p>Master Account: {{$character->account_name}}</p>
      <div class="char-answer">
        <form class="accept-char" action="/admin/character/review/{{$character->id}}" method="post">
          @method('PATCH')
          @csrf
          <button type="submit" name="accepted">Accept</button>
        </form>
        <form class="deny-char" action="/admin/character/review/{{$character->id}}" method="post">
          @method('PATCH')
          @csrf
          <button type="submit" name="dennied">Deny</button>
        </form>
      </div>
  @endforeach
@else
  {{ "No characters found" }}
@endif

@endsection
