@extends('layouts.ucp')

@section('content')

<form action="/saveticket" method="POST">
  @csrf
  <input type="text" name="subject" value="{{old('subject')}}" placeholder="Ticket title">
  <textarea name="issue" rows="8" cols="80" value="{{old('issue')}}" placeholder="Describe the issue as clear as possible"></textarea>
  <button type="submit" name="button">Create</button>
</form>
@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
