@extends('layouts.ucp')

<?php
$version = $application->question5;
switch ($version) {
  case 0:
  {
    $situation = 'What are you supposed to do when an offier asks for your ID while you know you have a "piece" on you?<br />(noun: piece = possesion of a firearm illegaly)';
    break;
  }
  case 1:
  {
    $situation = 'Someone breaks into your house and you grab your weapon from the nightshelf. What are you going to do next?';
    break;
  }
  case 2:
  {
    $situation = 'You walk down on some dark alley and someone starts calling you names. You know that individual as some old bully and you also have your weapon with you. What are you going to do?';
    break;
  }
  case 3:
  {
    $situation = 'You are in a store with your girlfriend/wife waiting in a queue at the checking table. Some individual decides to cut in front of you. What are you going to do?';
  }
  default:
      $situation = 'What are you supposed to do when an offier asks for your ID while you know you have a "piece" on you?<br />(noun: piece = possesion of a firearm illegaly)';
    break;
}
 ?>

@section('content')

<div class="apppreview">
  <h1 class="appuser">{{$application->username}}</h1>

  <div class="question">
    <p class="question1">What is the definition of MG (Meta-Gaming)?</p>
    <p class="answer1">{{$application->answer1}}</p>
  </div>

  <div class="question">
    <p class="question2">What is the definition of PG (Power-Gaming)?</p>
    <p class="answer2">{{$application->answer2}}</p>
  </div>

  <div class="question">
    <p class="question3">Explain the rules regarding robbing & the limitations.</p>
    <p class="answer3">{{$application->answer3}}</p>
  </div>

  <div class="question">
    <p class="question4">Write the story for your first character you will have.</p>
    <p class="answer4">{{$application->answer4}}</p>
  </div>

  <div class="question">
    <p class="question5">{!!$situation!!}</p>
    <p class="answer5">{{$application->answer5}}</p>
  </div>
</div>

<form class="acceptapp" action="/admin/application/answer/{{$application->id}}" method="POST">
    @method('PATCH')
    @csrf
    <button type="submit" name="accept">Accept</button>
</form>
<form class="acceptapp" action="/admin/application/answer/{{$application->id}}" method="POST">
    @method('PATCH')
    @csrf
    <textarea name="reason" rows="8" cols="80"></textarea>
    <button type="submit" name="deny">Deny</button>
</form>


@foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
@endforeach

@endsection
